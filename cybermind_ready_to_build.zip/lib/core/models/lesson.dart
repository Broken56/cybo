class Lesson {
  final String id;
  final String title;
  final String levelId;
  final String moduleId;
  final String objective;
  final String analogy;
  final String visualDescription;
  final String technicalExplanation;
  final String scenario;
  final List<QuizQuestion> questions;
  final List<String> keyPoints;
  final String practicalTakeaway;
  final String nextLessonId;
  final int estimatedMinutes;
  final List<String> tags;
  final String? urduSummary;
  final List<String> prerequisites;

  const Lesson({
    required this.id,
    required this.title,
    required this.levelId,
    required this.moduleId,
    required this.objective,
    required this.analogy,
    required this.visualDescription,
    required this.technicalExplanation,
    required this.scenario,
    required this.questions,
    required this.keyPoints,
    required this.practicalTakeaway,
    required this.nextLessonId,
    required this.estimatedMinutes,
    this.tags = const [],
    this.urduSummary,
    this.prerequisites = const [],
  });
}

class QuizQuestion {
  final String id;
  final String question;
  final List<String> options;
  final int correctIndex;
  final String explanation;
  final String? hint;

  const QuizQuestion({
    required this.id,
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.explanation,
    this.hint,
  });
}

class LearningLevel {
  final String id;
  final String title;
  final String description;
  final int order;
  final List<Module> modules;

  const LearningLevel({
    required this.id,
    required this.title,
    required this.description,
    required this.order,
    required this.modules,
  });
}

class Module {
  final String id;
  final String title;
  final String description;
  final List<String> lessonIds;

  const Module({
    required this.id,
    required this.title,
    required this.description,
    required this.lessonIds,
  });
}
