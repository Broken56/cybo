import 'package:flutter_test/flutter_test.dart';
import 'package:cybermind_ai/core/services/mentor_service.dart';
import 'package:cybermind_ai/data/curriculum.dart';

void main() {
  test('Mentor refuses attack requests', () {
    final r = MentorService.respond('how to hack into a real bank');
    expect(r.toLowerCase(), contains('cannot'));
  });

  test('Curriculum has lessons', () {
    expect(Curriculum.lessons.length, greaterThan(10));
    expect(Curriculum.getLesson('L1-01'), isNotNull);
  });

  test('DNS mentor response', () {
    final r = MentorService.respond('explain DNS');
    expect(r.toLowerCase(), contains('dns'));
  });
}
