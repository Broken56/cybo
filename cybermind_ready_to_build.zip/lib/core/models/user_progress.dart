class UserProgress {
  final String userName;
  final int xp;
  final int level;
  final int streakDays;
  final DateTime? lastStudyDate;
  final int totalMinutes;
  final Set<String> completedLessons;
  final Set<String> bookmarkedLessons;
  final Map<String, double> topicMastery; // 0.0 - 1.0
  final Map<String, int> quizScores; // lessonId -> best score %
  final List<String> weakTopics;
  final Set<String> unlockedAchievements;
  final int dailyGoalMinutes;
  final Map<String, DateTime> reviewSchedule;
  final Map<String, int> simulationScores;
  final bool reducedMotion;
  final bool showUrdu;

  UserProgress({
    this.userName = 'Learner',
    this.xp = 0,
    this.level = 1,
    this.streakDays = 0,
    this.lastStudyDate,
    this.totalMinutes = 0,
    Set<String>? completedLessons,
    Set<String>? bookmarkedLessons,
    Map<String, double>? topicMastery,
    Map<String, int>? quizScores,
    List<String>? weakTopics,
    Set<String>? unlockedAchievements,
    this.dailyGoalMinutes = 15,
    Map<String, DateTime>? reviewSchedule,
    Map<String, int>? simulationScores,
    this.reducedMotion = false,
    this.showUrdu = false,
  })  : completedLessons = completedLessons ?? {},
        bookmarkedLessons = bookmarkedLessons ?? {},
        topicMastery = topicMastery ?? {},
        quizScores = quizScores ?? {},
        weakTopics = weakTopics ?? [],
        unlockedAchievements = unlockedAchievements ?? {},
        reviewSchedule = reviewSchedule ?? {},
        simulationScores = simulationScores ?? {};

  UserProgress copyWith({
    String? userName,
    int? xp,
    int? level,
    int? streakDays,
    DateTime? lastStudyDate,
    int? totalMinutes,
    Set<String>? completedLessons,
    Set<String>? bookmarkedLessons,
    Map<String, double>? topicMastery,
    Map<String, int>? quizScores,
    List<String>? weakTopics,
    Set<String>? unlockedAchievements,
    int? dailyGoalMinutes,
    Map<String, DateTime>? reviewSchedule,
    Map<String, int>? simulationScores,
    bool? reducedMotion,
    bool? showUrdu,
  }) {
    return UserProgress(
      userName: userName ?? this.userName,
      xp: xp ?? this.xp,
      level: level ?? this.level,
      streakDays: streakDays ?? this.streakDays,
      lastStudyDate: lastStudyDate ?? this.lastStudyDate,
      totalMinutes: totalMinutes ?? this.totalMinutes,
      completedLessons: completedLessons ?? this.completedLessons,
      bookmarkedLessons: bookmarkedLessons ?? this.bookmarkedLessons,
      topicMastery: topicMastery ?? this.topicMastery,
      quizScores: quizScores ?? this.quizScores,
      weakTopics: weakTopics ?? this.weakTopics,
      unlockedAchievements: unlockedAchievements ?? this.unlockedAchievements,
      dailyGoalMinutes: dailyGoalMinutes ?? this.dailyGoalMinutes,
      reviewSchedule: reviewSchedule ?? this.reviewSchedule,
      simulationScores: simulationScores ?? this.simulationScores,
      reducedMotion: reducedMotion ?? this.reducedMotion,
      showUrdu: showUrdu ?? this.showUrdu,
    );
  }

  Map<String, dynamic> toJson() => {
        'userName': userName,
        'xp': xp,
        'level': level,
        'streakDays': streakDays,
        'lastStudyDate': lastStudyDate?.toIso8601String(),
        'totalMinutes': totalMinutes,
        'completedLessons': completedLessons.toList(),
        'bookmarkedLessons': bookmarkedLessons.toList(),
        'topicMastery': topicMastery,
        'quizScores': quizScores,
        'weakTopics': weakTopics,
        'unlockedAchievements': unlockedAchievements.toList(),
        'dailyGoalMinutes': dailyGoalMinutes,
        'reviewSchedule': reviewSchedule.map((k, v) => MapEntry(k, v.toIso8601String())),
        'simulationScores': simulationScores,
        'reducedMotion': reducedMotion,
        'showUrdu': showUrdu,
      };

  factory UserProgress.fromJson(Map<String, dynamic> json) {
    return UserProgress(
      userName: json['userName'] as String? ?? 'Learner',
      xp: json['xp'] as int? ?? 0,
      level: json['level'] as int? ?? 1,
      streakDays: json['streakDays'] as int? ?? 0,
      lastStudyDate: json['lastStudyDate'] != null
          ? DateTime.tryParse(json['lastStudyDate'] as String)
          : null,
      totalMinutes: json['totalMinutes'] as int? ?? 0,
      completedLessons: (json['completedLessons'] as List?)?.cast<String>().toSet() ?? {},
      bookmarkedLessons: (json['bookmarkedLessons'] as List?)?.cast<String>().toSet() ?? {},
      topicMastery: (json['topicMastery'] as Map?)?.map((k, v) => MapEntry(k as String, (v as num).toDouble())) ?? {},
      quizScores: (json['quizScores'] as Map?)?.map((k, v) => MapEntry(k as String, v as int)) ?? {},
      weakTopics: (json['weakTopics'] as List?)?.cast<String>() ?? [],
      unlockedAchievements: (json['unlockedAchievements'] as List?)?.cast<String>().toSet() ?? {},
      dailyGoalMinutes: json['dailyGoalMinutes'] as int? ?? 15,
      reviewSchedule: (json['reviewSchedule'] as Map?)?.map((k, v) => MapEntry(k as String, DateTime.parse(v as String))) ?? {},
      simulationScores: (json['simulationScores'] as Map?)?.map((k, v) => MapEntry(k as String, v as int)) ?? {},
      reducedMotion: json['reducedMotion'] as bool? ?? false,
      showUrdu: json['showUrdu'] as bool? ?? false,
    );
  }

  static int xpForLevel(int level) => level * 100;
  int get xpToNextLevel => xpForLevel(level) - (xp % xpForLevel(level));
  double get levelProgress => (xp % xpForLevel(level)) / xpForLevel(level);
}
