class MentorService {
  static const bool isOfflineMode = true;

  static String respond(String userMessage, {int learnerLevel = 1}) {
    final q = userMessage.toLowerCase().trim();
    if (q.isEmpty) {
      return 'Ask me about cybersecurity fundamentals, networking, defense, or AI security. Offline mentor mode — curated explanations.';
    }
    if (_isAttackRequest(q)) {
      return 'I cannot help with unauthorized attacks. Use Practice labs or ask about defensive concepts (firewalls, CIA triad, incident response).';
    }
    if (q.contains('dns')) return _dns(learnerLevel);
    if (q.contains('firewall')) return 'A firewall allows or blocks traffic by rules (IP, port, protocol). Prefer default-deny. Try Network Packet Explorer in Practice.';
    if (q.contains('cia') || q.contains('confidentiality')) {
      return 'CIA: Confidentiality (only authorized can read), Integrity (not altered undetected), Availability (usable when needed).';
    }
    if (q.contains('phishing')) {
      return 'Phishing uses urgency and trust. Check domains, links, sender. Use MFA. Practice in Phishing Investigator lab.';
    }
    if (q.contains('https') || q.contains('tls')) {
      return 'HTTPS = HTTP + TLS. Encrypts content, checks integrity, authenticates server via certificates.';
    }
    if (q.contains('mfa') || q.contains('2fa')) {
      return 'MFA requires multiple factors. Passkeys are phishing-resistant; SMS is weaker. Greatly reduces account takeover.';
    }
    if (q.contains('prompt injection') || q.contains('llm')) {
      return 'Prompt injection: untrusted text steers the model. Constrain tools, require approval for sensitive actions, verify outputs.';
    }
    if (q.contains('soc') || q.contains('siem')) {
      return 'SOC monitors alerts and responds. Triage: validate, prioritize, act. Practice in SOC Analyst Simulator.';
    }
    if (q.contains('incident')) {
      return 'IR phases: Prepare, Detect, Contain, Eradicate, Recover, Learn. Preserve logs. Try Incident Response Simulator.';
    }
    if (q.contains('least privilege') || q.contains('iam')) {
      return 'Least privilege: minimum access needed. Short-lived credentials. Reduces blast radius if compromised.';
    }
    if (q.contains('quiz') || q.contains('test me')) {
      return 'Quick check: (1) What does DNS do? (2) Name CIA triad. (3) Why default-deny firewall? Reply and I will explain.';
    }
    if (q.contains('ids') && q.contains('firewall')) {
      return 'Firewall filters by policy. IDS alerts on suspicious patterns. IPS can block. They complement each other.';
    }
    return 'Offline CyberMind mentor. Topics: DNS, firewalls, CIA, phishing, HTTPS, MFA, SOC, IR, prompt injection, least privilege.\n\nYou asked: "$userMessage"\n\nRephrase around those topics, or open a lesson in Learn.';
  }

  static bool _isAttackRequest(String q) {
    const bad = ['hack into', 'attack a real', 'steal password', 'crack password for', 'exploit this site', 'ddos', 'unauthorized access to'];
    return bad.any((b) => q.contains(b));
  }

  static String _dns(int level) {
    if (level <= 2) {
      return 'DNS is the internet phone book: names → IP addresses. Browser asks resolver, gets IP, then connects. Prefer HTTPS; watch for lookalike domains.';
    }
    return 'DNS resolves records (A/AAAA, MX, TXT). Security: DNSSEC, DoH/DoT, monitor for DGA/C2 domains. Log queries where policy allows.';
  }
}
