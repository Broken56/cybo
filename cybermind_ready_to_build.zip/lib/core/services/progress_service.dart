import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_progress.dart';

class ProgressService extends ChangeNotifier {
  static const _key = 'cybermind_progress_v1';
  UserProgress _progress = UserProgress();
  bool _loaded = false;

  UserProgress get progress => _progress;
  bool get isLoaded => _loaded;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw != null) {
      try {
        _progress = UserProgress.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      } catch (_) {
        _progress = UserProgress();
      }
    }
    _updateStreak();
    _loaded = true;
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(_progress.toJson()));
  }

  void _updateStreak() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final last = _progress.lastStudyDate;
    if (last == null) return;
    final lastDay = DateTime(last.year, last.month, last.day);
    final diff = today.difference(lastDay).inDays;
    if (diff > 1) {
      _progress = _progress.copyWith(streakDays: 0);
    }
  }

  Future<void> recordStudy({required int minutes, required String lessonId, int? quizScore}) async {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final last = _progress.lastStudyDate;
    int streak = _progress.streakDays;
    if (last == null) {
      streak = 1;
    } else {
      final lastDay = DateTime(last.year, last.month, last.day);
      final diff = today.difference(lastDay).inDays;
      if (diff == 1) {
        streak += 1;
      } else if (diff > 1) {
        streak = 1;
      }
    }

    final completed = Set<String>.from(_progress.completedLessons)..add(lessonId);
    final scores = Map<String, int>.from(_progress.quizScores);
    if (quizScore != null) {
      final prev = scores[lessonId] ?? 0;
      if (quizScore > prev) scores[lessonId] = quizScore;
    }

    int xpGain = 20 + minutes * 2;
    if (quizScore != null && quizScore >= 80) xpGain += 30;
    if (quizScore != null && quizScore == 100) xpGain += 20;

    int newXp = _progress.xp + xpGain;
    int newLevel = _progress.level;
    while (newXp >= UserProgress.xpForLevel(newLevel)) {
      newXp -= UserProgress.xpForLevel(newLevel);
      newLevel += 1;
    }

    final mastery = Map<String, double>.from(_progress.topicMastery);
    final current = mastery[lessonId] ?? 0.0;
    final boost = quizScore != null ? quizScore / 100.0 : 0.6;
    mastery[lessonId] = (current + (1 - current) * boost * 0.5).clamp(0.0, 1.0);

    final achievements = Set<String>.from(_progress.unlockedAchievements);
    if (completed.length == 1) achievements.add('first_lesson');
    if (completed.length >= 5) achievements.add('five_lessons');
    if (streak >= 3) achievements.add('streak_3');
    if (streak >= 7) achievements.add('streak_7');
    if (quizScore == 100) achievements.add('perfect_quiz');

    final reviews = Map<String, DateTime>.from(_progress.reviewSchedule);
    final intervalDays = mastery[lessonId]! > 0.8 ? 7 : (mastery[lessonId]! > 0.5 ? 3 : 1);
    reviews[lessonId] = today.add(Duration(days: intervalDays));

    _progress = _progress.copyWith(
      xp: newXp,
      level: newLevel,
      streakDays: streak,
      lastStudyDate: now,
      totalMinutes: _progress.totalMinutes + minutes,
      completedLessons: completed,
      quizScores: scores,
      topicMastery: mastery,
      unlockedAchievements: achievements,
      reviewSchedule: reviews,
    );
    await _save();
    notifyListeners();
  }

  Future<void> toggleBookmark(String lessonId) async {
    final bookmarks = Set<String>.from(_progress.bookmarkedLessons);
    if (bookmarks.contains(lessonId)) {
      bookmarks.remove(lessonId);
    } else {
      bookmarks.add(lessonId);
    }
    _progress = _progress.copyWith(bookmarkedLessons: bookmarks);
    await _save();
    notifyListeners();
  }

  Future<void> recordSimulation(String simId, int score) async {
    final scores = Map<String, int>.from(_progress.simulationScores);
    final prev = scores[simId] ?? 0;
    if (score > prev) scores[simId] = score;
    final achievements = Set<String>.from(_progress.unlockedAchievements);
    if (simId == 'phishing') achievements.add('phishing_investigator');
    if (simId == 'soc') achievements.add('soc_apprentice');
    if (simId == 'packet') achievements.add('network_detective');
    if (simId == 'ai_verify') achievements.add('ai_verifier');
    if (simId == 'incident') achievements.add('first_incident');
    int xpGain = 15 + (score ~/ 10);
    int newXp = _progress.xp + xpGain;
    int newLevel = _progress.level;
    while (newXp >= UserProgress.xpForLevel(newLevel)) {
      newXp -= UserProgress.xpForLevel(newLevel);
      newLevel += 1;
    }
    _progress = _progress.copyWith(
      simulationScores: scores,
      unlockedAchievements: achievements,
      xp: newXp,
      level: newLevel,
    );
    await _save();
    notifyListeners();
  }

  Future<void> setUserName(String name) async {
    _progress = _progress.copyWith(userName: name);
    await _save();
    notifyListeners();
  }

  Future<void> setDailyGoal(int minutes) async {
    _progress = _progress.copyWith(dailyGoalMinutes: minutes);
    await _save();
    notifyListeners();
  }

  Future<void> setReducedMotion(bool value) async {
    _progress = _progress.copyWith(reducedMotion: value);
    await _save();
    notifyListeners();
  }

  Future<void> setShowUrdu(bool value) async {
    _progress = _progress.copyWith(showUrdu: value);
    await _save();
    notifyListeners();
  }

  Future<void> resetAll() async {
    _progress = UserProgress();
    await _save();
    notifyListeners();
  }

  String exportJson() => jsonEncode(_progress.toJson());
}
